tellraw @a [{"text":"ChatClear has been ","color":"gray"},{"text":"successfully","color":"green"},{"text":" loaded!","color":"gray"}]
